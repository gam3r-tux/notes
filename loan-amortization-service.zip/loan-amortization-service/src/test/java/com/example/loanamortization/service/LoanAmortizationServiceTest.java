package com.example.loanamortization.service;

import com.example.loanamortization.config.InterestRateProperties;
import com.example.loanamortization.dto.AmortizationResponseDTO;
import com.example.loanamortization.exception.RateNotFoundException;
import com.example.loanamortization.service.impl.PropertiesInterestRateProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class LoanAmortizationServiceTest {

    private LoanAmortizationService service;

    @BeforeEach
    void setUp() {
        InterestRateProperties properties = new InterestRateProperties();
        properties.setRateRanges(Arrays.asList(
                rango(0, 99999, "17.1"),
                rango(100000, 2499999, "16.5"),
                rango(2500000, 4999999, "15.9"),
                rango(5000000, 9999999, "15.6"),
                rango(10000000, -1, "14.2")
        ));

        InterestRateProvider provider = new PropertiesInterestRateProvider(properties);
        service = new LoanAmortizationService(provider);
    }

    private InterestRateProperties.RateRange rango(long min, long max, String tasa) {
        InterestRateProperties.RateRange r = new InterestRateProperties.RateRange();
        r.setMinAmount(min);
        r.setMaxAmount(max);
        r.setAnnualRate(new BigDecimal(tasa));
        return r;
    }

    @Test
    @DisplayName("Caso 1: prestamo de $158,000 debe aplicar tasa 16.5%")
    void testAmortizacion_montoEnRangoMedio_158000() {
        AmortizationResponseDTO response = service.calculateAmortization(158000);

        assertEquals(158000L, response.getMontoCredito());
        assertEquals(new BigDecimal("16.5"), response.getTasaInteresAnual());
        // 158000 * 0.165 = 26070.00
        assertEquals(new BigDecimal("26070.00"), response.getInteresesPagar());
        // 158000 + 26070 = 184070.00
        assertEquals(new BigDecimal("184070.00"), response.getPagoTotalCredito());
    }

    @Test
    @DisplayName("Caso 2: prestamo de $10,000,001 debe aplicar tasa 14.2% (tramo sin limite superior)")
    void testAmortizacion_montoEnRangoMasAlto_10000001() {
        AmortizationResponseDTO response = service.calculateAmortization(10000001);

        assertEquals(10000001L, response.getMontoCredito());
        assertEquals(new BigDecimal("14.2"), response.getTasaInteresAnual());
        // 10000001 * 0.142 = 1420000.142 -> redondeado a 1420000.14
        assertEquals(new BigDecimal("1420000.14"), response.getInteresesPagar());
        // 10000001 + 1420000.14 = 11420001.14
        assertEquals(new BigDecimal("11420001.14"), response.getPagoTotalCredito());
    }

    @Test
    @DisplayName("Monto fuera de cualquier rango configurado debe lanzar RateNotFoundException")
    void testAmortizacion_montoSinRangoConfigurado_lanzaExcepcion() {
        InterestRateProperties properties = new InterestRateProperties();
        properties.setRateRanges(Arrays.asList(rango(0, 99999, "17.1"))); // rango incompleto a proposito
        LoanAmortizationService serviceConHueco =
                new LoanAmortizationService(new PropertiesInterestRateProvider(properties));

        assertThrows(RateNotFoundException.class, () -> serviceConHueco.calculateAmortization(500000));
    }
}
