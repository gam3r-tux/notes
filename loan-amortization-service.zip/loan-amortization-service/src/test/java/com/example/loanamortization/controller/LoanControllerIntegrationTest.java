package com.example.loanamortization.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Levanta el contexto completo de Spring Boot (con la implementacion basada
 * en properties, que es la activa por defecto) y ejercita el endpoint real
 * via HTTP simulado, con los dos casos de uso solicitados.
 */
@SpringBootTest
@AutoConfigureMockMvc
class LoanControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("GET /api/v1/loans/amortization?montoCredito=158000 -> tasa 16.5%")
    void whenMonto158000_thenTasa16_5() throws Exception {
        mockMvc.perform(get("/api/v1/loans/amortization").param("montoCredito", "158000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.montoCredito", is(158000)))
                .andExpect(jsonPath("$.tasaInteresAnual", is(16.5)))
                .andExpect(jsonPath("$.interesesPagar", is(26070.00)))
                .andExpect(jsonPath("$.pagoTotalCredito", is(184070.00)));
    }

    @Test
    @DisplayName("GET /api/v1/loans/amortization?montoCredito=10000001 -> tasa 14.2%")
    void whenMonto10000001_thenTasa14_2() throws Exception {
        mockMvc.perform(get("/api/v1/loans/amortization").param("montoCredito", "10000001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.montoCredito", is(10000001)))
                .andExpect(jsonPath("$.tasaInteresAnual", is(14.2)))
                .andExpect(jsonPath("$.interesesPagar", is(1420000.14)))
                .andExpect(jsonPath("$.pagoTotalCredito", is(11420001.14)));
    }

    @Test
    @DisplayName("Monto por debajo del minimo (0) debe retornar 400")
    void whenMontoInvalido_thenBadRequest() throws Exception {
        mockMvc.perform(get("/api/v1/loans/amortization").param("montoCredito", "0"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Monto por encima del maximo permitido debe retornar 400")
    void whenMontoExcedeMaximo_thenBadRequest() throws Exception {
        mockMvc.perform(get("/api/v1/loans/amortization").param("montoCredito", "1000000001"))
                .andExpect(status().isBadRequest());
    }
}
