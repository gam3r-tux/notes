-- =====================================================================
-- Tabla de parametros: rangos de monto y tasa anual de interes.
-- Enfoque recomendado para produccion (ver README.md, seccion
-- "Properties vs. tabla de parametros").
-- =====================================================================

CREATE TABLE TASA_INTERES_PRESTAMO (
    ID                      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    MONTO_MINIMO            BIGINT NOT NULL,
    MONTO_MAXIMO            BIGINT,                         -- NULL = sin limite superior
    TASA_ANUAL              DECIMAL(5,2) NOT NULL,           -- ej: 16.50
    ACTIVO                  SMALLINT NOT NULL DEFAULT 1,     -- 1 = activo, 0 = inactivo
    FECHA_VIGENCIA_DESDE    DATE NOT NULL,
    FECHA_VIGENCIA_HASTA    DATE,
    FECHA_CREACION          TIMESTAMP DEFAULT CURRENT TIMESTAMP,
    USUARIO_CREACION        VARCHAR(50),

    CONSTRAINT CK_TASA_RANGO CHECK (MONTO_MAXIMO IS NULL OR MONTO_MAXIMO > MONTO_MINIMO)
);

CREATE INDEX IX_TASA_MONTO_MINIMO ON TASA_INTERES_PRESTAMO (MONTO_MINIMO);

-- Carga inicial equivalente a la tabla de negocio entregada
INSERT INTO TASA_INTERES_PRESTAMO
    (MONTO_MINIMO, MONTO_MAXIMO, TASA_ANUAL, FECHA_VIGENCIA_DESDE, USUARIO_CREACION)
VALUES
    (0,        99999,      17.1, CURRENT DATE, 'SETUP'),
    (100000,   2499999,    16.5, CURRENT DATE, 'SETUP'),
    (2500000,  4999999,    15.9, CURRENT DATE, 'SETUP'),
    (5000000,  9999999,    15.6, CURRENT DATE, 'SETUP'),
    (10000000, NULL,       14.2, CURRENT DATE, 'SETUP');

-- Ejemplo de actualizacion de una tasa sin tocar codigo ni redeployar:
-- UPDATE TASA_INTERES_PRESTAMO SET TASA_ANUAL = 16.0
--   WHERE MONTO_MINIMO = 100000 AND ACTIVO = 1;
