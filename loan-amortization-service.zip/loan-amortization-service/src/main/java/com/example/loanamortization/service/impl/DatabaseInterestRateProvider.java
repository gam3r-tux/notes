package com.example.loanamortization.service.impl;

import com.example.loanamortization.entity.InterestRateEntity;
import com.example.loanamortization.exception.RateNotFoundException;
import com.example.loanamortization.repository.InterestRateRepository;
import com.example.loanamortization.service.InterestRateProvider;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * Implementacion RECOMENDADA PARA PRODUCCION. Lee los rangos activos desde la
 * tabla TASA_INTERES_PRESTAMO en DB2 a traves de InterestRateRepository.
 *
 * Se activa arrancando la aplicacion con -Dspring.profiles.active=db2-rates.
 *
 * Usa @Cacheable para no consultar DB2 en cada llamada del endpoint (el
 * catalogo de tasas cambia con poca frecuencia). La cache se invalida:
 *   1) automaticamente cada 30 minutos (salvaguarda), y
 *   2) bajo demanda, llamando a refreshCache() desde un endpoint
 *      administrativo cuando alguien actualiza la tabla.
 */
@Service
@Profile("db2-rates")
public class DatabaseInterestRateProvider implements InterestRateProvider {

    private final InterestRateRepository repository;

    public DatabaseInterestRateProvider(InterestRateRepository repository) {
        this.repository = repository;
    }

    @Override
    @Cacheable("interestRates")
    public BigDecimal getRateForAmount(long loanAmount) {
        List<InterestRateEntity> ranges = repository.findByActiveTrueOrderByMinAmountAsc();
        return ranges.stream()
                .filter(r -> loanAmount >= r.getMinAmount()
                        && (r.getMaxAmount() == null || loanAmount <= r.getMaxAmount()))
                .map(InterestRateEntity::getAnnualRate)
                .findFirst()
                .orElseThrow(() -> new RateNotFoundException(
                        "No existe una tasa configurada para el monto: " + loanAmount));
    }

    @CacheEvict(value = "interestRates", allEntries = true)
    @Scheduled(fixedRate = 30 * 60 * 1000)
    public void refreshCache() {
        // El cuerpo puede quedar vacio: la anotacion @CacheEvict limpia la
        // cache "interestRates" en cada invocacion (programada o manual);
        // la siguiente consulta recarga los datos desde DB2.
    }
}
