package com.example.loanamortization.dto;

import java.math.BigDecimal;

/**
 * Representa el registro unico de la "tabla de amortizacion" solicitada:
 * monto original, tasa aplicada, intereses generados y pago total.
 */
public class AmortizationResponseDTO {

    private Long montoCredito;
    private BigDecimal tasaInteresAnual;
    private BigDecimal interesesPagar;
    private BigDecimal pagoTotalCredito;

    public AmortizationResponseDTO() {
    }

    public AmortizationResponseDTO(Long montoCredito, BigDecimal tasaInteresAnual,
                                    BigDecimal interesesPagar, BigDecimal pagoTotalCredito) {
        this.montoCredito = montoCredito;
        this.tasaInteresAnual = tasaInteresAnual;
        this.interesesPagar = interesesPagar;
        this.pagoTotalCredito = pagoTotalCredito;
    }

    public Long getMontoCredito() {
        return montoCredito;
    }

    public void setMontoCredito(Long montoCredito) {
        this.montoCredito = montoCredito;
    }

    public BigDecimal getTasaInteresAnual() {
        return tasaInteresAnual;
    }

    public void setTasaInteresAnual(BigDecimal tasaInteresAnual) {
        this.tasaInteresAnual = tasaInteresAnual;
    }

    public BigDecimal getInteresesPagar() {
        return interesesPagar;
    }

    public void setInteresesPagar(BigDecimal interesesPagar) {
        this.interesesPagar = interesesPagar;
    }

    public BigDecimal getPagoTotalCredito() {
        return pagoTotalCredito;
    }

    public void setPagoTotalCredito(BigDecimal pagoTotalCredito) {
        this.pagoTotalCredito = pagoTotalCredito;
    }
}
