package com.example.loanamortization.service;

import com.example.loanamortization.dto.AmortizationResponseDTO;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class LoanAmortizationService {

    private final InterestRateProvider interestRateProvider;

    public LoanAmortizationService(InterestRateProvider interestRateProvider) {
        this.interestRateProvider = interestRateProvider;
    }

    /**
     * Calcula el registro unico de amortizacion para un monto de credito:
     * busca la tasa anual correspondiente al rango del monto, calcula los
     * intereses (monto x tasa) y el pago total (monto + intereses).
     *
     * @param loanAmount monto del prestamo (1 a 1,000,000,000)
     * @return DTO con monto original, tasa aplicada, intereses y pago total
     */
    public AmortizationResponseDTO calculateAmortization(long loanAmount) {
        BigDecimal annualRate = interestRateProvider.getRateForAmount(loanAmount);
        BigDecimal amount = BigDecimal.valueOf(loanAmount);

        // Tasa anual expresada en porcentaje (ej: 16.5) -> fraccion (0.165)
        BigDecimal rateFraction = annualRate.divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP);

        BigDecimal interest = amount.multiply(rateFraction).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalPayment = amount.add(interest).setScale(2, RoundingMode.HALF_UP);

        return new AmortizationResponseDTO(loanAmount, annualRate, interest, totalPayment);
    }
}
