package com.example.loanamortization.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Entidad que representa la tabla de parametros TASA_INTERES_PRESTAMO en DB2.
 * Enfoque de almacenamiento por TABLA DE PARAMETROS (recomendado para produccion):
 * permite actualizar rangos y tasas sin redeployar el microservicio, mantiene
 * historial/vigencia y puede auditarse.
 */
@Entity
@Table(name = "TASA_INTERES_PRESTAMO")
public class InterestRateEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "MONTO_MINIMO", nullable = false)
    private Long minAmount;

    /** NULL significa "sin limite superior" (ultimo tramo de la tabla). */
    @Column(name = "MONTO_MAXIMO")
    private Long maxAmount;

    @Column(name = "TASA_ANUAL", nullable = false, precision = 5, scale = 2)
    private BigDecimal annualRate;

    @Column(name = "ACTIVO", nullable = false)
    private Boolean active = Boolean.TRUE;

    @Column(name = "FECHA_VIGENCIA_DESDE")
    private LocalDate effectiveFrom;

    @Column(name = "FECHA_VIGENCIA_HASTA")
    private LocalDate effectiveTo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(Long minAmount) {
        this.minAmount = minAmount;
    }

    public Long getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(Long maxAmount) {
        this.maxAmount = maxAmount;
    }

    public BigDecimal getAnnualRate() {
        return annualRate;
    }

    public void setAnnualRate(BigDecimal annualRate) {
        this.annualRate = annualRate;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public LocalDate getEffectiveFrom() {
        return effectiveFrom;
    }

    public void setEffectiveFrom(LocalDate effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
    }

    public LocalDate getEffectiveTo() {
        return effectiveTo;
    }

    public void setEffectiveTo(LocalDate effectiveTo) {
        this.effectiveTo = effectiveTo;
    }
}
