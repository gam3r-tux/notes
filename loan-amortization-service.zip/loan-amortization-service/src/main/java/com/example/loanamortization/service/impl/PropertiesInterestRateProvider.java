package com.example.loanamortization.service.impl;

import com.example.loanamortization.config.InterestRateProperties;
import com.example.loanamortization.exception.RateNotFoundException;
import com.example.loanamortization.service.InterestRateProvider;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Implementacion ACTIVA POR DEFECTO. Lee los rangos desde InterestRateProperties
 * (application.yml). Se desactiva automaticamente si se levanta la aplicacion
 * con el perfil "db2-rates".
 */
@Service
@Profile("!db2-rates")
public class PropertiesInterestRateProvider implements InterestRateProvider {

    private final InterestRateProperties properties;

    public PropertiesInterestRateProvider(InterestRateProperties properties) {
        this.properties = properties;
    }

    @Override
    public BigDecimal getRateForAmount(long loanAmount) {
        return properties.getRateRanges().stream()
                .filter(r -> loanAmount >= r.getMinAmount()
                        && (r.getMaxAmount() == -1 || loanAmount <= r.getMaxAmount()))
                .map(InterestRateProperties.RateRange::getAnnualRate)
                .findFirst()
                .orElseThrow(() -> new RateNotFoundException(
                        "No existe una tasa configurada para el monto: " + loanAmount));
    }
}
