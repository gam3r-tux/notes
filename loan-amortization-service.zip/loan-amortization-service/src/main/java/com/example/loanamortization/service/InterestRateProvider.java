package com.example.loanamortization.service;

import java.math.BigDecimal;

/**
 * Abstrae el origen de la tabla de rangos/tasas. La logica de negocio
 * (LoanAmortizationService) no necesita saber si la tasa viene de un
 * archivo application.yml o de una tabla en DB2: solo pide la tasa
 * para un monto dado. Esto permite cambiar de implementacion sin tocar
 * el servicio ni el controlador (principio de inversion de dependencias).
 */
public interface InterestRateProvider {

    BigDecimal getRateForAmount(long loanAmount);
}
