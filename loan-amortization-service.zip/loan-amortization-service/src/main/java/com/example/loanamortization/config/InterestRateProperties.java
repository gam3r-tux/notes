package com.example.loanamortization.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;
import java.util.List;

/**
 * Mapea la lista de rangos/tasas definida en application.yml bajo la clave "loan.rate-ranges".
 * Enfoque de almacenamiento por PROPERTIES: sencillo, versionado en Git, pero requiere
 * reconstruir/redeployar la aplicacion para modificar un rango o una tasa.
 */
@ConfigurationProperties(prefix = "loan")
public class InterestRateProperties {

    private List<RateRange> rateRanges;

    public List<RateRange> getRateRanges() {
        return rateRanges;
    }

    public void setRateRanges(List<RateRange> rateRanges) {
        this.rateRanges = rateRanges;
    }

    public static class RateRange {

        /** Monto minimo del rango (inclusive). */
        private long minAmount;

        /** Monto maximo del rango (inclusive). Usar -1 para "sin limite superior". */
        private long maxAmount;

        /** Tasa anual expresada como porcentaje, ej: 16.5 representa 16.5%. */
        private BigDecimal annualRate;

        public long getMinAmount() {
            return minAmount;
        }

        public void setMinAmount(long minAmount) {
            this.minAmount = minAmount;
        }

        public long getMaxAmount() {
            return maxAmount;
        }

        public void setMaxAmount(long maxAmount) {
            this.maxAmount = maxAmount;
        }

        public BigDecimal getAnnualRate() {
            return annualRate;
        }

        public void setAnnualRate(BigDecimal annualRate) {
            this.annualRate = annualRate;
        }
    }
}
