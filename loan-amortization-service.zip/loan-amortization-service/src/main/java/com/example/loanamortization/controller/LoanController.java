package com.example.loanamortization.controller;

import com.example.loanamortization.dto.AmortizationResponseDTO;
import com.example.loanamortization.service.LoanAmortizationService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@RestController
@RequestMapping("/api/v1/loans")
@Validated
public class LoanController {

    private final LoanAmortizationService loanAmortizationService;

    public LoanController(LoanAmortizationService loanAmortizationService) {
        this.loanAmortizationService = loanAmortizationService;
    }

    /**
     * GET /api/v1/loans/amortization?montoCredito=158000
     *
     * Retorna el registro unico de amortizacion (monto, tasa aplicada,
     * intereses y pago total) segun el rango en el que caiga montoCredito.
     */
    @GetMapping("/amortization")
    public AmortizationResponseDTO getAmortization(
            @RequestParam("montoCredito")
            @Min(value = 1, message = "El monto del credito debe ser mayor o igual a 1")
            @Max(value = 1_000_000_000, message = "El monto del credito debe ser menor o igual a 1,000,000,000")
            Integer montoCredito) {

        return loanAmortizationService.calculateAmortization(montoCredito);
    }
}
