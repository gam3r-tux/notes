package com.example.loanamortization.repository;

import com.example.loanamortization.entity.InterestRateEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InterestRateRepository extends JpaRepository<InterestRateEntity, Long> {

    List<InterestRateEntity> findByActiveTrueOrderByMinAmountAsc();
}
