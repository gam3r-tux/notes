package com.example.loanamortization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.example.loanamortization.config.InterestRateProperties;

@SpringBootApplication
@EnableConfigurationProperties(InterestRateProperties.class)
public class LoanAmortizationApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoanAmortizationApplication.class, args);
    }
}
