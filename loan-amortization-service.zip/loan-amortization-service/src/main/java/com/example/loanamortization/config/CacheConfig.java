package com.example.loanamortization.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Habilita cache en memoria y tareas programadas.
 * Se usa unicamente cuando el perfil "db2-rates" esta activo, ya que la
 * implementacion basada en properties no necesita cache (los valores ya
 * estan en memoria desde el arranque de la aplicacion).
 */
@Configuration
@EnableCaching
@EnableScheduling
public class CacheConfig {
}
