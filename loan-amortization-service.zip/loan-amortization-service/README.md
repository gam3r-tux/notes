# loan-amortization-service

Microservicio Spring Boot (Java 8, Maven, DB2) que expone un endpoint para calcular
un registro único de amortización de un préstamo, según la tasa anual que corresponda
al rango del monto solicitado.

## Tabla de rangos y tasas usada

> **Nota sobre la tabla original:** el enunciado tenía los límites invertidos
> (`>` en ambos extremos) y el primer tramo decía "Crédito > 100,000,000", lo cual
> deja sin tasa definida a montos entre 10,000,000 y 100,000,000 — justo donde cae
> uno de los casos de prueba pedidos ($10,000,001). Se asumió que ese tramo debía
> ser "Crédito > 10,000,000" para que la tabla no tenga huecos y sea consistente
> con los casos de prueba. Si el corte real es en 100,000,000, solo hay que
> cambiar una línea en `application.yml` (`min-amount: 10000000` → `100000000`).

| Rango del préstamo         | Tasa anual |
|-----------------------------|-----------:|
| $0 – $99,999                | 17.1%      |
| $100,000 – $2,499,999       | 16.5%      |
| $2,500,000 – $4,999,999     | 15.9%      |
| $5,000,000 – $9,999,999     | 15.6%      |
| $10,000,000 en adelante     | 14.2%      |

## Endpoint

```
GET /api/v1/loans/amortization?montoCredito={entero entre 1 y 1000000000}
```

**Ejemplo de request:**
```
GET /api/v1/loans/amortization?montoCredito=158000
```

**Ejemplo de response (200 OK):**
```json
{
  "montoCredito": 158000,
  "tasaInteresAnual": 16.5,
  "interesesPagar": 26070.00,
  "pagoTotalCredito": 184070.00
}
```

Cálculo aplicado (registro único, no amortización periódica):
- `interesesPagar = montoCredito * (tasaInteresAnual / 100)`
- `pagoTotalCredito = montoCredito + interesesPagar`

**Errores:**
- `400 Bad Request` — si `montoCredito` está fuera de [1, 1,000,000,000] o no es numérico.
- `404 Not Found` — si el monto no cae en ningún rango configurado (no debería ocurrir
  con la tabla completa, pero queda cubierto por si se edita mal la configuración).

## Dónde vive cada pieza

```
src/main/java/com/example/loanamortization/
├── controller/        LoanController (endpoint), GlobalExceptionHandler
├── service/            LoanAmortizationService (cálculo), InterestRateProvider (interfaz)
│   └── impl/            PropertiesInterestRateProvider, DatabaseInterestRateProvider
├── config/              InterestRateProperties (mapea application.yml), CacheConfig
├── entity/ repository/  InterestRateEntity + InterestRateRepository (para DB2)
├── dto/                  AmortizationResponseDTO
└── exception/            RateNotFoundException, InvalidLoanAmountException
```

La lógica de negocio (`LoanAmortizationService`) depende únicamente de la interfaz
`InterestRateProvider`, no de cómo se obtienen las tasas. Esto permite cambiar el
origen de datos (properties ↔ DB2) sin tocar el servicio ni el controlador.

## Properties vs. tabla de parámetros en DB2 — ¿cuál usar?

| | **application.yml (properties)** | **Tabla de parámetros en DB2** |
|---|---|---|
| Actualizar un rango/tasa | Requiere editar el archivo, recompilar y **redeployar** | `UPDATE` en la tabla, sin tocar código ni redeployar |
| Quién puede actualizar | Solo el equipo de desarrollo/DevOps | Un área de negocio/operaciones vía un módulo administrativo |
| Historial de cambios / auditoría | Solo vía Git (quién cambió el archivo) | Nativo en la tabla (`FECHA_VIGENCIA_DESDE/HASTA`, `USUARIO_CREACION`, `ACTIVO`) |
| Tasas vigentes a futuro (ej. "esta tasa aplica desde el 1 de enero") | No soportado de forma natural | Soportado con columnas de vigencia |
| Complejidad / infraestructura | Mínima | Requiere acceso a DB2, JPA, y opcionalmente caché |
| Rendimiento | Datos ya en memoria desde el arranque | Requiere caché para no consultar DB2 en cada request |
| Consistencia entre ambientes | Un archivo por ambiente (dev/qa/prod), fácil de versionar | Hay que mantener la tabla sincronizada por ambiente |

**Recomendación:** para un microservicio de reglas de negocio financieras que
cambian con cierta frecuencia (tasas de interés), lo más adecuado en producción
es la **tabla de parámetros en DB2**, porque:

1. Permite que negocio/operaciones actualice tasas sin depender de un ciclo de
   release del microservicio.
2. Deja trazabilidad de quién y cuándo cambió una tasa (auditoría, requisito
   común en el sector financiero).
3. Soporta vigencias (una tasa nueva puede programarse para entrar en vigor en
   una fecha futura sin tocar la tabla el mismo día).
4. Se puede exponer un endpoint administrativo (protegido) para invalidar la
   caché tras una actualización, manteniendo el rendimiento de una consulta en
   memoria el resto del tiempo.

El **archivo de properties** es razonable solo si las tasas cambian muy poco
(por ejemplo, una vez al año, en un cambio regulatorio) y el equipo está
cómodo con que cualquier cambio pase por un despliegue formal.

Este proyecto implementa **ambos** enfoques detrás de la misma interfaz
(`InterestRateProvider`), para que la decisión sea un cambio de configuración,
no de código:

- Por defecto (sin perfiles activos) usa `PropertiesInterestRateProvider`.
- Con `-Dspring.profiles.active=db2-rates` usa `DatabaseInterestRateProvider`,
  que lee de la tabla `TASA_INTERES_PRESTAMO` (ver `src/main/resources/db2-schema.sql`)
  y cachea el resultado (`@Cacheable`) para no golpear DB2 en cada request; la
  caché se refresca cada 30 minutos o bajo demanda vía `refreshCache()`.

## Cómo correr el proyecto

```bash
mvn clean install
mvn spring-boot:run
```

Para usar el enfoque de DB2 en lugar de properties, ajustar primero la
conexión en `application.yml` (o vía variables `DB2_USERNAME` / `DB2_PASSWORD`)
y arrancar con:

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=db2-rates
```

## Tests incluidos

- `LoanAmortizationServiceTest` (unitario, sin levantar contexto Spring):
  - **Caso 1:** monto `$158,000` → tasa `16.5%`, intereses `$26,070.00`, total `$184,070.00`.
  - **Caso 2:** monto `$10,000,001` → tasa `14.2%`, intereses `$1,420,000.14`, total `$11,420,001.14`.
  - Caso adicional: monto sin rango configurado → `RateNotFoundException`.
- `LoanControllerIntegrationTest` (`@SpringBootTest` + `MockMvc`): los mismos
  dos casos ejercitados a través del endpoint HTTP real, más validación de
  montos fuera de rango (`400 Bad Request`).

Ejecutar solo los tests:
```bash
mvn test
```
