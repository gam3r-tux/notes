package com.example.clienteinfo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ClienteNoEncontradoException.class)
    public ResponseEntity<Object> handleClienteNoEncontrado(ClienteNoEncontradoException ex) {
        return build(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    @ExceptionHandler(ConfiguracionEndpointException.class)
    public ResponseEntity<Object> handleConfiguracion(ConfiguracionEndpointException ex) {
        return build(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
    }

    @ExceptionHandler(HttpClientErrorException.class)
    public ResponseEntity<Object> handleClientError(HttpClientErrorException ex) {
        return build(HttpStatus.valueOf(ex.getStatusCode().value()),
                "El endpoint externo respondio con error: " + ex.getStatusCode());
    }

    @ExceptionHandler(HttpServerErrorException.class)
    public ResponseEntity<Object> handleServerError(HttpServerErrorException ex) {
        return build(HttpStatus.BAD_GATEWAY, "Error interno del servicio externo");
    }

    @ExceptionHandler(ResourceAccessException.class)
    public ResponseEntity<Object> handleTimeout(ResourceAccessException ex) {
        return build(HttpStatus.GATEWAY_TIMEOUT, "No fue posible contactar al servicio externo");
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> handleIllegalArgument(IllegalArgumentException ex) {
        return build(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    private ResponseEntity<Object> build(HttpStatus status, String mensaje) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", Instant.now().toString());
        body.put("status", status.value());
        body.put("mensaje", mensaje);
        return ResponseEntity.status(status).body(body);
    }
}
