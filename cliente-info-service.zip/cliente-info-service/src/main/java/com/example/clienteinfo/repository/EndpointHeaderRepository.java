package com.example.clienteinfo.repository;

import com.example.clienteinfo.entity.EndpointHeader;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EndpointHeaderRepository extends JpaRepository<EndpointHeader, Long> {

    List<EndpointHeader> findByEndpointId(Long endpointId);
}
