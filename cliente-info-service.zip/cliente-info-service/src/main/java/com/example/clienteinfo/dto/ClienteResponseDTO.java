package com.example.clienteinfo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * JSON condensado que expone nuestro servicio.
 * Estos campos son un EJEMPLO: reemplazar por los campos reales
 * que su servicio debe entregar, tomados del JSON del endpoint externo.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClienteResponseDTO {

    private String identificador;
    private String nombreCompleto;
    private String correoElectronico;
    private String telefono;
    private String estado;
}
