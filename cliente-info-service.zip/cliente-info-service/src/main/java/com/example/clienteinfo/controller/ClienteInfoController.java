package com.example.clienteinfo.controller;

import com.example.clienteinfo.dto.ClienteResponseDTO;
import com.example.clienteinfo.service.ClienteInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/clientes")
@RequiredArgsConstructor
public class ClienteInfoController {

    private final ClienteInfoService clienteInfoService;

    // GET /api/v1/clientes/1234567890
    @GetMapping("/{clienteId}")
    public ResponseEntity<ClienteResponseDTO> obtenerCliente(@PathVariable String clienteId) {
        ClienteResponseDTO respuesta = clienteInfoService.obtenerInformacionCliente(clienteId);
        return ResponseEntity.ok(respuesta);
    }
}
