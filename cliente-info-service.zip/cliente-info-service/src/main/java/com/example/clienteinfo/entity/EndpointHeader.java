package com.example.clienteinfo.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * Mapea la tabla en DB2 donde se almacenan los headers HTTP requeridos por el endpoint.
 *
 * Ejemplo de tabla:
 * CREATE TABLE ENDPOINT_HEADER (
 *     ID              INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 *     ENDPOINT_ID     INTEGER NOT NULL REFERENCES ENDPOINT_CONFIG(ID),
 *     NOMBRE_HEADER   VARCHAR(100) NOT NULL,
 *     VALOR_HEADER    VARCHAR(500) NOT NULL
 * );
 */
@Entity
@Table(name = "ENDPOINT_HEADER", schema = "SCHEMA_APP")
@Getter
@Setter
public class EndpointHeader {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "ENDPOINT_ID", nullable = false)
    private Long endpointId;

    @Column(name = "NOMBRE_HEADER", nullable = false, length = 100)
    private String nombreHeader;

    @Column(name = "VALOR_HEADER", nullable = false, length = 500)
    private String valorHeader;
}
