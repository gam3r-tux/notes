package com.example.clienteinfo.exception;

public class ConfiguracionEndpointException extends RuntimeException {
    public ConfiguracionEndpointException(String mensaje) {
        super(mensaje);
    }

    public ConfiguracionEndpointException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
