package com.example.clienteinfo.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * Mapea la tabla en DB2 donde se almacena la URL del endpoint externo.
 * Ajustar nombre de tabla/esquema/columnas a los reales de su BD.
 *
 * Ejemplo de tabla:
 * CREATE TABLE ENDPOINT_CONFIG (
 *     ID              INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 *     CODIGO          VARCHAR(50) NOT NULL,   -- identificador logico del endpoint, ej: 'CLIENTE_INFO'
 *     URL_BASE        VARCHAR(500) NOT NULL,  -- puede incluir placeholder {clienteId}
 *     METODO_HTTP     VARCHAR(10) DEFAULT 'GET',
 *     ACTIVO          CHAR(1) DEFAULT 'S'
 * );
 */
@Entity
@Table(name = "ENDPOINT_CONFIG", schema = "SCHEMA_APP")
@Getter
@Setter
public class EndpointConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CODIGO", nullable = false, length = 50)
    private String codigo;

    @Column(name = "URL_BASE", nullable = false, length = 500)
    private String urlBase;

    @Column(name = "METODO_HTTP", length = 10)
    private String metodoHttp;

    @Column(name = "ACTIVO", length = 1)
    private String activo;
}
