package com.example.clienteinfo.service;

import com.example.clienteinfo.dto.ClienteResponseDTO;
import com.example.clienteinfo.entity.EndpointConfig;
import com.example.clienteinfo.entity.EndpointHeader;
import com.example.clienteinfo.exception.ClienteNoEncontradoException;
import com.example.clienteinfo.exception.ConfiguracionEndpointException;
import com.example.clienteinfo.repository.EndpointConfigRepository;
import com.example.clienteinfo.repository.EndpointHeaderRepository;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ClienteInfoService {

    // Codigo logico con el que se identifica este endpoint en la tabla ENDPOINT_CONFIG
    private static final String CODIGO_ENDPOINT_CLIENTE = "CLIENTE_INFO";
    private static final String ACTIVO = "S";
    private static final Pattern PATRON_10_DIGITOS = Pattern.compile("^\\d{10}$");

    private final EndpointConfigRepository endpointConfigRepository;
    private final EndpointHeaderRepository endpointHeaderRepository;
    private final RestTemplate restTemplate;

    public ClienteResponseDTO obtenerInformacionCliente(String clienteId) {
        validarClienteId(clienteId);

        EndpointConfig config = endpointConfigRepository
                .findByCodigoAndActivo(CODIGO_ENDPOINT_CLIENTE, ACTIVO)
                .orElseThrow(() -> new ConfiguracionEndpointException(
                        "No se encontro configuracion activa para el endpoint '" + CODIGO_ENDPOINT_CLIENTE + "'"));

        String urlFinal = construirUrl(config.getUrlBase(), clienteId);
        HttpHeaders headers = construirHeaders(config.getId());
        HttpMethod metodo = HttpMethod.resolve(
                config.getMetodoHttp() != null ? config.getMetodoHttp() : "GET");

        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<JsonNode> response;
        try {
            response = restTemplate.exchange(urlFinal, metodo != null ? metodo : HttpMethod.GET,
                    requestEntity, JsonNode.class);
        } catch (Exception ex) {
            throw ex; // el GlobalExceptionHandler traduce los distintos tipos a HTTP status
        }

        if (response.getStatusCode() == HttpStatus.NOT_FOUND || response.getBody() == null) {
            throw new ClienteNoEncontradoException("No se encontro informacion para el cliente " + clienteId);
        }

        return mapearRespuesta(response.getBody());
    }

    private void validarClienteId(String clienteId) {
        if (clienteId == null || !PATRON_10_DIGITOS.matcher(clienteId).matches()) {
            throw new IllegalArgumentException("El identificador del cliente debe ser una cadena de 10 digitos");
        }
    }

    /**
     * Si la URL almacenada contiene el placeholder {clienteId} se reemplaza ahi.
     * Si no lo contiene, se asume que el identificador va como ultimo segmento de la ruta.
     */
    private String construirUrl(String urlBase, String clienteId) {
        if (urlBase == null || urlBase.isEmpty()) {
            throw new ConfiguracionEndpointException("La URL configurada para el endpoint esta vacia");
        }
        if (urlBase.contains("{clienteId}")) {
            return urlBase.replace("{clienteId}", clienteId);
        }
        return urlBase.endsWith("/") ? urlBase + clienteId : urlBase + "/" + clienteId;
    }

    private HttpHeaders construirHeaders(Long endpointId) {
        HttpHeaders headers = new HttpHeaders();
        List<EndpointHeader> headersConfigurados = endpointHeaderRepository.findByEndpointId(endpointId);
        for (EndpointHeader h : headersConfigurados) {
            headers.add(h.getNombreHeader(), h.getValorHeader());
        }
        return headers;
    }

    /**
     * Mapea unicamente los campos requeridos desde el JSON completo del endpoint externo
     * hacia el DTO condensado. AJUSTAR los nombres de los campos de origen (get("..."))
     * segun la estructura real del JSON que retorna el servicio externo.
     */
    private ClienteResponseDTO mapearRespuesta(JsonNode raiz) {
        return ClienteResponseDTO.builder()
                .identificador(textoSeguro(raiz, "id"))
                .nombreCompleto(textoSeguro(raiz, "nombreCompleto"))
                .correoElectronico(textoSeguro(raiz, "correo"))
                .telefono(textoSeguro(raiz, "telefono"))
                .estado(textoSeguro(raiz, "estado"))
                .build();
    }

    private String textoSeguro(JsonNode nodo, String campo) {
        JsonNode valor = nodo.get(campo);
        return (valor != null && !valor.isNull()) ? valor.asText() : null;
    }
}
