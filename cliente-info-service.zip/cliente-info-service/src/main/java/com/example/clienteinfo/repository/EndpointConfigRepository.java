package com.example.clienteinfo.repository;

import com.example.clienteinfo.entity.EndpointConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EndpointConfigRepository extends JpaRepository<EndpointConfig, Long> {

    Optional<EndpointConfig> findByCodigoAndActivo(String codigo, String activo);
}
