# cliente-info-service

Servicio Spring Boot 2.7.18 (Java 8) empaquetado como WAR para desplegarse en OpenLiberty.
Recibe el identificador de un cliente (10 dígitos), consulta un endpoint externo cuya
URL y headers están almacenados en tablas de IBM DB2, y devuelve un JSON condensado con
solo los campos necesarios.

## Flujo

1. `ClienteInfoController` recibe `GET /api/v1/clientes/{clienteId}`.
2. `ClienteInfoService`:
   - Valida que `clienteId` tenga exactamente 10 dígitos.
   - Lee de `ENDPOINT_CONFIG` (vía `EndpointConfigRepository`) la URL base registrada
     para el código lógico `CLIENTE_INFO`.
   - Lee de `ENDPOINT_HEADER` (vía `EndpointHeaderRepository`) los headers asociados
     a ese endpoint.
   - Sustituye el identificador en la URL (soporta placeholder `{clienteId}` o lo
     agrega como último segmento de la ruta).
   - Llama al endpoint externo con `RestTemplate`.
   - Mapea únicamente los campos requeridos del JSON de respuesta al DTO
     `ClienteResponseDTO`.
3. Los errores (cliente no encontrado, configuración faltante, timeout, error del
   servicio externo) se traducen a respuestas HTTP consistentes en
   `GlobalExceptionHandler`.

## Cosas que DEBEN ajustarse antes de usar en un ambiente real

- **Nombres reales de tablas/columnas/esquema** en `EndpointConfig` y `EndpointHeader`
  (actualmente `SCHEMA_APP.ENDPOINT_CONFIG` / `SCHEMA_APP.ENDPOINT_HEADER`, con columnas
  de ejemplo).
- **Campos del JSON origen y destino** en `ClienteInfoService.mapearRespuesta(...)` y en
  `ClienteResponseDTO`: hoy son un ejemplo (`id`, `nombreCompleto`, `correo`, `telefono`,
  `estado`). Reemplazar por los nombres reales del JSON que retorna el endpoint del
  cliente y por los campos que ustedes quieran exponer.
- **Datos de conexión a DB2** en `application.yml` (host, puerto, base de datos,
  usuario/password — idealmente vía variables de entorno o vault, no en texto plano).
- **Versión del driver JDBC de DB2** (`com.ibm.db2:jcc`) en el `pom.xml`, según la que
  les entregue su DBA (puede no estar en Maven Central, en cuyo caso hay que instalarlo
  en un repositorio interno/Nexus o como `system` scope apuntando al jar entregado por IBM).
- **Formato de la URL almacenada**: el código soporta tanto
  `https://host/servicio/{clienteId}` (con placeholder) como
  `https://host/servicio` (el id se concatena al final). Ajustar `construirUrl(...)`
  si el formato real es distinto (ej. el id va como query param).

## Compilar y correr localmente con Liberty

```bash
mvn clean package
mvn liberty:run
```

El servicio quedará disponible en `http://localhost:9080/api/v1/clientes/{clienteId}`.

## Ejemplo de tablas DB2

```sql
CREATE TABLE SCHEMA_APP.ENDPOINT_CONFIG (
    ID          INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    CODIGO      VARCHAR(50) NOT NULL,
    URL_BASE    VARCHAR(500) NOT NULL,
    METODO_HTTP VARCHAR(10) DEFAULT 'GET',
    ACTIVO      CHAR(1) DEFAULT 'S'
);

CREATE TABLE SCHEMA_APP.ENDPOINT_HEADER (
    ID            INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    ENDPOINT_ID   INTEGER NOT NULL REFERENCES SCHEMA_APP.ENDPOINT_CONFIG(ID),
    NOMBRE_HEADER VARCHAR(100) NOT NULL,
    VALOR_HEADER  VARCHAR(500) NOT NULL
);

INSERT INTO SCHEMA_APP.ENDPOINT_CONFIG (CODIGO, URL_BASE, METODO_HTTP, ACTIVO)
VALUES ('CLIENTE_INFO', 'https://api.externo.com/clientes/{clienteId}', 'GET', 'S');

INSERT INTO SCHEMA_APP.ENDPOINT_HEADER (ENDPOINT_ID, NOMBRE_HEADER, VALOR_HEADER)
VALUES (1, 'Authorization', 'Bearer xxxxx'),
       (1, 'x-api-key', 'yyyyy');
```
