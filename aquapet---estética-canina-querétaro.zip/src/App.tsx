import { motion, useScroll, useTransform } from "motion/react";
import { Dog, MapPin, Phone, MessageCircle, ArrowRight, Sparkles, Scissors, Truck } from "lucide-react";
import { useRef } from "react";

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  return (
    <div className="bg-white min-h-screen" ref={containerRef}>
      {/* Navigation - Artistic Flair Style */}
      <header className="fixed top-0 left-0 w-full z-50 h-20 bg-white/95 backdrop-blur-sm border-b border-gray-100 flex justify-between items-center px-6 md:px-[60px]">
        <div className="flex items-center gap-1 font-black text-2xl tracking-tighter uppercase logo">
          GUAU!<span className="text-art-purple">ESTÉTICA</span>
        </div>
        <nav className="hidden md:block">
          <ul className="flex gap-[30px] text-xs font-bold uppercase tracking-widest text-art-ink">
            <li><a href="#inicio" className="hover:text-art-purple transition-colors">Inicio</a></li>
            <li><a href="#servicios" className="hover:text-art-purple transition-colors">Servicios</a></li>
            <li><a href="#ubicacion" className="hover:text-art-purple transition-colors">Ubicación</a></li>
            <li><a href="#contacto" className="hover:text-art-purple transition-colors">Contacto</a></li>
          </ul>
        </nav>
        <a 
          href="https://wa.me/524423567890" 
          target="_blank" 
          rel="noopener noreferrer"
          className="hidden sm:flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-art-blue hover:text-art-purple transition-colors"
        >
          <Phone className="w-4 h-4" />
          442-356-7890
        </a>
      </header>

      <main className="pt-20">
        {/* Artistic Flair Hero Layout */}
        <section id="inicio" className="min-h-[calc(100vh-80px)] flex flex-col md:flex-row relative">
          <div className="flex-[1.2] p-6 md:p-[60px] flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-6xl md:text-[84px] font-extrabold leading-[0.9] mb-6 block bg-gradient-to-br from-art-blue to-art-purple bg-clip-text text-transparent">
                Súper<br />Pet Friendly.
              </h1>
              <p className="text-lg text-art-muted max-w-[400px] leading-relaxed mb-10">
                La estética canina que se adapta a tu estilo de vida. Cuidado profesional con amor y respeto por cada pata.
              </p>
              <div>
                <a 
                  href="https://wa.me/524423567890" 
                  className="whatsapp-cta inline-block px-10 py-5 bg-art-turquoise text-white font-bold rounded-[4px] shadow-[0_10px_20px_rgba(0,206,201,0.2)] hover:transform hover:translate-y-[-2px] transition-all"
                >
                  WhatsApp 442-356-7890
                </a>
              </div>
              <div className="mt-12 md:mt-24 text-[12px] font-semibold flex items-center gap-[10px] opacity-50 scroll-indicator">
                <div className="w-[6px] h-[6px] bg-black rounded-full dot"></div> SCROLL TO DISCOVER
              </div>
            </motion.div>
          </div>

          <div className="flex-1 bg-gray-100 grid grid-cols-2 grid-rows-2 services-grid">
            <div className="p-10 flex flex-col justify-between bg-art-purple text-white service-card card-purple">
              <div className="text-[11px] uppercase tracking-[2px] font-bold opacity-80 service-label tracking-widest">Concepto</div>
              <div className="text-[28px] font-bold mt-[10px] leading-tight service-title font-display">Digital<br />Minimalism</div>
            </div>
            <div className="p-10 flex flex-col justify-between bg-art-turquoise text-white service-card card-turquoise">
              <div className="text-[11px] uppercase tracking-[2px] font-bold opacity-80 service-label tracking-widest">A domicilio</div>
              <div className="text-[28px] font-bold mt-[10px] leading-tight service-title font-display">Vamos a<br />tu puerta</div>
            </div>
            <div className="p-10 flex flex-col justify-between bg-art-blue text-white service-card card-blue">
              <div className="text-[11px] uppercase tracking-[2px] font-bold opacity-80 service-label tracking-widest">Grooming</div>
              <div className="text-[28px] font-bold mt-[10px] leading-tight service-title font-display">Cuidado<br />Premium</div>
            </div>
            <div className="p-10 flex flex-col justify-between bg-art-green text-white service-card card-green">
              <div className="text-[11px] uppercase tracking-[2px] font-bold opacity-80 service-label tracking-widest">Nuestro local</div>
              <div className="text-[28px] font-bold mt-[10px] leading-tight service-title font-display">Paseo de<br />las Armas</div>
            </div>
          </div>
        </section>

        {/* Scrollytelling Content - Preserving original content with theme styling */}
        <section id="ubicacion" className="relative h-[200vh]">
          <div className="sticky top-20 h-[calc(100vh-80px)] flex flex-col md:flex-row items-center overflow-hidden">
            <div className="w-full md:w-1/2 h-1/2 md:h-full p-8 md:p-[60px] flex flex-col justify-center bg-white z-10">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <div className="text-[11px] uppercase tracking-[2px] font-bold text-art-blue mb-2">Visítanos</div>
                <h2 className="text-5xl md:text-7xl font-bold mb-6 text-art-ink leading-tight">
                  Nuestro <br />Espacio.
                </h2>
                <p className="text-lg text-art-muted mb-8 leading-relaxed max-w-md">
                  Ubicados en el corazón de Querétaro, diseñamos un local minimalista y seguro donde tu mascota se sentirá en casa.
                </p>
                <div className="flex items-center gap-4 text-art-purple font-bold text-sm tracking-wide">
                  <MapPin className="w-5 h-5" />
                  <span>Paseo de las Armas, Col. Las Fuentes</span>
                </div>
              </motion.div>
            </div>
            <div className="w-full md:w-1/2 h-1/2 md:h-full relative overflow-hidden">
              <motion.img 
                style={{ scale: useTransform(scrollYProgress, [0.1, 0.3], [1, 1.1]) }}
                src="input_file_2.png" 
                alt="Local AquaPet" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </section>

        <section className="relative h-[200vh] bg-gray-50">
          <div className="sticky top-20 h-[calc(100vh-80px)] flex flex-col md:flex-row-reverse items-center overflow-hidden">
            <div className="w-full md:w-1/2 h-1/2 md:h-full p-8 md:p-[60px] flex flex-col justify-center z-10">
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: false }}
                transition={{ duration: 0.8 }}
              >
                <div className="text-[11px] uppercase tracking-[2px] font-bold text-art-green mb-2">Especialistas</div>
                <h2 className="text-5xl md:text-7xl font-bold mb-6 text-art-ink leading-tight">
                  Llegamos <br />a Tu Puerta.
                </h2>
                <p className="text-lg text-art-muted mb-8 leading-relaxed max-w-md">
                  ¿Sin tiempo de salir? Nuestra unidad móvil está totalmente equipada para brindar el servicio completo de spa en la comodidad de tu hogar.
                </p>
                <div className="flex items-center gap-4 text-art-turquoise font-bold text-sm tracking-wide">
                  <Truck className="w-5 h-5" />
                  <span>Servicio a Domicilio Querétaro</span>
                </div>
              </motion.div>
            </div>
            <div className="w-full md:w-1/2 h-1/2 md:h-full relative overflow-hidden">
              <motion.img 
                style={{ scale: useTransform(scrollYProgress, [0.3, 0.6], [1.1, 1]) }}
                src="input_file_3.png" 
                alt="Unidad Móvil" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </section>

        <section id="servicios" className="py-32 px-6 md:px-[60px] bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto">
            <div className="text-left mb-20 flex flex-col md:flex-row md:items-end justify-between gap-8">
              <div>
                <div className="text-[11px] uppercase tracking-[2px] font-bold text-art-purple mb-2 tracking-widest">Nuestra Calidad</div>
                <h2 className="text-5xl md:text-8xl font-bold text-art-ink leading-[0.9] tracking-tighter">
                  Transformación <br /><span className="text-art-purple">con Amor.</span>
                </h2>
              </div>
              <p className="text-xl text-art-muted max-w-xl font-light">Resultados impecables que resaltan la belleza y salud de tu mascota.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-[60px] items-start">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="rounded-lg overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.1)] relative group"
              >
                <img src="input_file_1.png" alt="Antes y Después" className="w-full aspect-[4/3] object-cover" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-art-purple/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </motion.div>
              
              <div className="space-y-12">
                {[
                  { icon: <Sparkles className="text-art-turquoise" />, title: "Baño Premium", desc: "Productos orgánicos y secado a mano para un pelaje radiante." },
                  { icon: <Scissors className="text-art-purple" />, title: "Corte Estilizado", desc: "Según la raza o preferencia, siempre respetando la salud de la piel." },
                  { icon: <Sparkles className="text-art-green" />, title: "Higiene Completa", desc: "Corte de uñas, limpieza de oídos y glándulas anales." },
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex gap-8 group"
                  >
                    <div className="w-16 h-16 rounded-full border border-gray-100 flex items-center justify-center bg-white shadow-sm group-hover:bg-art-ink group-hover:text-white transition-all duration-300">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="font-extrabold text-2xl mb-2 tracking-tight">{item.title}</h3>
                      <p className="text-art-muted leading-relaxed max-w-sm">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="relative h-screen">
          <img 
            src="input_file_0.png" 
            alt="Comunidad AquaPet" 
            className="w-full h-full object-cover grayscale-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-art-ink/40 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-center max-w-4xl"
            >
              <h2 className="text-7xl md:text-[120px] font-black text-white mb-8 tracking-tighter leading-[0.8] mix-blend-overlay">
                AMAMOS <br />LO QUE HACEMOS.
              </h2>
              <div className="h-px w-[60px] bg-white mx-auto mb-8"></div>
              <p className="text-2xl text-white font-light tracking-wide">Más que una estética, somos parte del bienestar de tu familia.</p>
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer - Artistic Flair Style */}
      <footer id="contacto" className="h-auto md:h-[120px] bg-art-ink text-white flex flex-col md:flex-row justify-between items-center px-6 md:px-[60px] py-10 md:py-0 gap-8">
        <div className="flex flex-col md:flex-row gap-8 md:gap-16 items-center">
          <div className="text-sm font-medium leading-relaxed uppercase address-box text-center md:text-left">
            <span className="block text-[11px] text-[#B2BEC3] uppercase mb-1 tracking-widest">Dirección Principal</span>
            Paseo de las Armas, Col. Las Fuentes<br />
            Querétaro, Qro. 76190
          </div>
          <div className="text-sm font-medium leading-relaxed uppercase address-box text-center md:text-left">
            <span className="block text-[11px] text-[#B2BEC3] uppercase mb-1 tracking-widest">Contacto Directo</span>
            442-356-7890<br />
            info@aquapet.mx
          </div>
        </div>
        
        <div className="text-sm font-medium text-center md:text-right address-box">
          <span className="block text-[11px] text-[#B2BEC3] uppercase mb-1 tracking-widest">Experiencia Nginx</span>
          Optimized for Linux Systems<br />
          Ready for /usr/share/nginx/html
        </div>
      </footer>
    </div>
  );
}
